﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace unit18
//Jaaged Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] arr = new int[4][];
            {
                arr[0] = new int[] { 11, 21, 56, 78 };
                arr[1] = new int[3] { 2, 3, 5 };
                arr[2] = new int[] { 2, 5, 6, 7, 98, 5 };
                arr[3] = new int[] { 2, 5, 11, 23, 50, 23 };
            }

            // Traverse array elements  
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {
                    Console.Write(arr[i][j] + " ");

                }
                Console.Read();
            }
        }
    }
}
