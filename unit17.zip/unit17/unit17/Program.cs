﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace unit17
//loop
{
    class Program
    {
        static void Main(string[] args)
        {
            //For Loop
            int i, j;
            for (i = 1; i <= 5; i++)
            {
                for (j = 1; j <= i; j++)
                {
                    Console.Write(j);
                }
                Console.WriteLine();
            }
            Console.WriteLine();

            //While Loop
            int k = 1 ;
            while (k <= 5)
            {
                int l = 1;
                while (l <= k)
                {
                    Console.Write(l);
                    l++;
                }
                Console.WriteLine();
                k++;
            }
            Console.WriteLine();

            //Do..While Loop [Exit Control]
            int m = 1;
            do
            {
                int n = 1;
                do
                {
                    Console.Write(n);
                    n++;
                } while (n <= m);
                Console.WriteLine();
                m++;
            } while (m <= 5);
            
            Console.Read();
        }
    }
}
