﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace ConsoleApplication1
{
    public delegate void delEvenHanler();
    internal class program : Form
    {
        public event delEvenHanler add;
        public program()
        {
            Button btn = new Button();
            btn.Parent = this;
            btn.Text = "Click Me";
            btn.Location = new Point(100, 100);
            btn.Click += new EventHandler(onClick);
        }
        public void onClick(object sender, EventArgs e)
        {
            MessageBox.Show("Click!");
        }
        static void Main(string[] args)
        {
            Application.Run(new program());
            Console.Read();
        }
    }
}
