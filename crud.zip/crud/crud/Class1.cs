﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace crud
{
    class Class1
    {
        public static  SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\STUD\Documents\crud1.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        public static int menuitem = 0;
    }
}
