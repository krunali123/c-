﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace crud
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Show();
        }
        private void fileToolstripMenuItem_Click(object sender, EventArgs e)
        {

            Class1.menuitem = 0;
            Employee emp = new Employee();
            emp.Show();
        }

        private void upateEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Class1.menuitem = 2;
            Employee emp = new Employee();
            emp.Show();
        }

        private void employeeToolStripMenItem_Click(object sender, EventArgs e)
        {
            Class1.menuitem = 1;
            Employee emp = new Employee();
            emp.Show();
        }

        private void employeeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Class1.menuitem = 3;
            Employee emp = new Employee();
            emp.Show();
        }

       

       

       

    }
}
