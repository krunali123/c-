﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace crud
{
    public partial class Employee : Form
    {
        string id = string.Empty;
        int tr = 0;
        int rp = 0;
        public Employee()
        {
            InitializeComponent();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void btnEmp_Click(object sender, EventArgs e)
        {
            string sql = string.Empty;
            string msg = string.Empty;
            if (btnEmp.Text == "&Add Employee")
            {
                if (cmbEmpDept.Text != "Select Department" && txtEmpName.Text != "" && txtEmpSalary.Text != "")
                {
                    sql = "insert into emp values('" + id + "','" + txtEmpName.Text + "','" + cmbEmpDept.Text + "','" + dtEmpJoinDate.Text + "','" + txtEmpSalary.Text + "')";
                    msg = "Insert!";
                }
            }
            else if (btnEmp.Text == "&Update Employee")
            {
                if (cmbEmpDept.Text != "Select Department" && txtEmpName.Text != "" && txtEmpSalary.Text != "")
                {
                    sql = "update emp set emp_name='" + txtEmpName.Text + "',emp_dept='" + cmbEmpDept.Text + "',join_date='" + dtEmpJoinDate.Text + "',salary='" + txtEmpSalary.Text + "' where emp_id='" + txtEmpID.Text + "'";
                    msg = "Update!";
                    rp = 0;
                }
            }
            else if (btnEmp.Text == "&Delete Employee")
            {
                sql = "delete from emp where emp_id='" + txtEmpID.Text + "'";
                msg = "Delete!";
                rp = 0;
            }
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show(msg, "App", MessageBoxButtons.OK, MessageBoxIcon.Information);
            getdata();

            if (btnEmp.Text == "&Add Employee" || tr < 0)
            {
                txtEmpName.Text = txtEmpSalary.Text = string.Empty;
                cmbEmpDept.Text = "Select Department";
                dtEmpJoinDate.Text = DateTime.Now.ToString();
                txtEmpName.Focus();
                if (btnEmp.Text == "&Delete Employee" || btnEmp.Text == "&Update Employee")
                {
                    btnEmp.Enabled = false;
                }
            }
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            if(Class1.menuitem == 0)
            {
                btnFirst.Visible = true;
                btnNext.Visible = true;
                btnPrev.Visible = true;
                btnLast.Visible = true;
            }
            else if(Class1.menuitem == 1)
            {
                btnEmp.Visible = false;
                btnEmp.Text = "";
            }
            else if(Class1.menuitem == 2)
            {
                btnEmp.Text = "&Update Employee";
            }
            else if(Class1.menuitem == 3)
            {
                btnEmp.Text = "&Delete Employee";  
            }
            getdata();
        }
         private void getdata()
        {
            dtEmpJoinDate.MaxDate = DateTime.Now;
            string sql = "select * from emp";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            tr = dt.Rows.Count - 1;
            if (Class1.menuitem == 0)
            {
                if (dt.Rows.Count == 0)
                {
                    id = "EMP0001";
                    txtEmpID.Text = id;
                }
                else
                {
                    int cs = dt.Rows.Count - 1;
                    string tempid = dt.Rows[tr][0].ToString();
                    string getid = tempid.Substring(3);
                    int newtempid = Convert.ToInt32(getid) + 1;
                    txtEmpID.Text = "EMP" + newtempid.ToString("0000");
                    id = txtEmpID.Text;
                }
            }
            else
            {
                if (dt.Rows.Count > 0)
                {
                    txtEmpID.Text = dt.Rows[rp][0].ToString();
                    txtEmpName.Text = dt.Rows[rp][1].ToString();
                    cmbEmpDept.Text = dt.Rows[rp][2].ToString();
                    dtEmpJoinDate.Text = dt.Rows[rp][3].ToString();
                    txtEmpSalary.Text = dt.Rows[rp][4].ToString();
                }
                else
                {
                    if (btnEmp.Text != "&Add Employee")
                    {
                        btnFirst.Enabled = false;
                        btnNext.Enabled = true;
                        btnPrev.Enabled = false;
                        btnLast.Enabled = false;
                        btnEmp.Enabled = false;
                    }
                }
            }
        }

        private void txtEmpSalary_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar))
				{ 
					e.Handled = false;
				}
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            
             if (rp < tr)
            {
                rp++;
                getdata();
            }
        
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
        
            if (rp > 0)
            {
                rp--;
                getdata();
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
             if (tr > 0)
            {
                rp = tr;
                getdata();
            }
        
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            if (tr > 0)
            {
                rp = 0;
                getdata();
            }
        
        }




        }


        }
    
